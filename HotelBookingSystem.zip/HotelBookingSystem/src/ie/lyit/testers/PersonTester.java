package ie.lyit.testers;

import ie.lyit.hotel.*;

public class PersonTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Name james = new Name("Mr", "James", "May");
		Date cardExp = new Date(15,02,2028);
		
	}

}
